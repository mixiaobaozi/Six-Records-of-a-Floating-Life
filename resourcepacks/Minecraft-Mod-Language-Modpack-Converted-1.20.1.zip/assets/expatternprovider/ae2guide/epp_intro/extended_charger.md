---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: 扩展充能器
    icon: expatternprovider:ex_charger
categories:
- extended devices
item_ids:
- expatternprovider:ex_charger
---

# 扩展充能器

<Row gap="20">
<BlockImage id="expatternprovider:ex_charger" scale="8"></BlockImage>
</Row>

扩展充能器是一种更高级的<ItemLink id="ae2:charger" />。

它最多可以同时充能4个物品。
