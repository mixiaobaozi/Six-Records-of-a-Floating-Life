---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME无限元件
    icon: expatternprovider:infinity_cell
categories:
- extended items
item_ids:
- expatternprovider:infinity_cell
---

# ME无限元件

一个简易的无限水源和圆石源，不过是元件形式的。

<Row>
<ItemImage id="expatternprovider:infinity_cell" scale="4"></ItemImage>
</Row>

它们存储有21亿的物品/流体！并且你可以从中无限地提取圆石/水，或者无限地存入圆石/水。